from src.server.instance import server
from src.routes.usersRoute import *
from src.routes.emailsRoute import *
from src.routes.groupsRoute import *
from src.routes.channelsRoute import *

server.run()